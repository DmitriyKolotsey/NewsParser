package com.example.recview;

public class Phone {

    private String name;
    private String company;
    private String time;

    public Phone(String time, String name, String company){
        this.time=time;
        this.name=name;
        this.company = company;
    }

    public String getTime(){
        return this.time;
    }

    public void setTime(String time){
        this.time = time;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompany() {
        return this.company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}